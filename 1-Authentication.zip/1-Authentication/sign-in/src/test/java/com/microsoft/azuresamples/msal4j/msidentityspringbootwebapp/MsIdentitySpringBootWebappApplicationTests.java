package com.microsoft.azuresamples.msal4j.msidentityspringbootwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsIdentitySpringBootWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
